interface CheckoutPopupProps {
  show: boolean;
  onClose: () => void;
  variant: string | null;
  size: string | null;
  discountApplied: boolean;
}

const variantLabels: Record<string, string> = {
  kima: "গরুর কিমার ঝালমুড়ি মশলা",
  chuijhal: "চুইঝালের স্পেশাল ঝালমুড়ি মশলা",
};

const sizeData: Record<string, { label: string; price: number }> = {
  "500ml": { label: "৫০০ ml", price: 650 },
  "1l": { label: "১ লিটার", price: 1090 },
};

const CheckoutPopup = ({ show, onClose, variant, size, discountApplied }: CheckoutPopupProps) => {
  if (!show || !variant || !size) return null;

  const s = sizeData[size];
  const discount = discountApplied ? 50 : 0;
  const total = s.price - discount;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" onClick={onClose}>
      <div className="animate-popup-overlay fixed inset-0 bg-foreground/40" />
      <div
        className="animate-popup-enter relative z-10 w-full max-w-md rounded-t-2xl bg-card p-6 shadow-2xl sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute right-4 top-4 text-xl text-muted-foreground hover:text-foreground">✕</button>

        <h3 className="mb-4 text-xl font-bold text-foreground">🧾 অর্ডার সামারি</h3>

        <div className="space-y-3 rounded-lg bg-muted/50 p-4">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">ভ্যারিয়েন্ট</span>
            <span className="font-medium text-foreground">{variantLabels[variant]}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">সাইজ</span>
            <span className="font-medium text-foreground">{s.label}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">মূল্য</span>
            <span className="font-medium text-foreground">৳{s.price}</span>
          </div>
          {discountApplied && (
            <div className="flex justify-between text-sm">
              <span className="text-primary">ডিসকাউন্ট</span>
              <span className="font-medium text-primary">-৳{discount}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">ডেলিভারি</span>
            <span className="font-medium text-primary">ফ্রি</span>
          </div>
          <div className="border-t border-border pt-3 flex justify-between">
            <span className="font-bold text-foreground">মোট</span>
            <span className="text-xl font-bold text-primary">৳{total}</span>
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          অর্ডার কনফার্ম করতে আমাদের প্রতিনিধি শীঘ্রই আপনার সাথে যোগাযোগ করবেন।
        </p>

        <button
          onClick={onClose}
          className="mt-4 w-full rounded-full bg-primary py-3.5 text-lg font-bold text-primary-foreground shadow-lg transition-transform hover:scale-[1.02] active:scale-95"
        >
          ✅ কনফার্ম করুন
        </button>
      </div>
    </div>
  );
};

export default CheckoutPopup;
