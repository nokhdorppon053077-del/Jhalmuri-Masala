const points = [
  { icon: "👃", title: "লোভনীয় ঘ্রাণ", desc: "মশলার ঘ্রান এতটাই লোভনীয় যে এর ঘ্রানে আপনার জিভে পানি চলে আসবে।" },
  { icon: "🧪", title: "সম্পূর্ণ ক্যামিকেলমুক্ত", desc: "আমাদের ঝালমুড়ির মশলা সম্পূর্ণ ক্যামিকেলমুক্ত, আলহামদুলিল্লাহ।" },
  { icon: "🏅", title: "ফাস্ট গ্রেড মশলা", desc: "এতে ব্যবহৃত সব মশলা ১০০% ফাস্ট গ্রেড মশলা।" },
  { icon: "🤫", title: "সিক্রেট রেসিপি", desc: "আমরাই বাংলাদেশে সর্বপ্রথম রাস্তার মামাদের সেই সিক্রেট ঝালমুড়ির মশলাটি আপনাদের দিচ্ছি।" },
  { icon: "🕐", title: "দীর্ঘ সংরক্ষণ", desc: "যেকোনো পরিবেশে (ঠান্ডা অথবা গরমে) ৬ মাসের উপরে সংরক্ষণ করে ব্যবহার করতে পারবেন।" },
  { icon: "🍚", title: "বহুমুখী ব্যবহার", desc: "ঝালমুড়ি ছাড়াও এই মশলা আপনি ভাত, রুটি এবং চিতই পিঠা দিয়েও খেতে পারবেন।" },
];

const WhyChooseUs = () => (
  <section className="bg-background px-5 py-12">
    <div className="mx-auto max-w-lg">
      <h2 className="mb-8 text-center text-xl font-bold text-foreground md:text-2xl">
        ✅ Toha Organic Foods থেকেই কেনো নিবেন?
      </h2>
      <div className="space-y-4">
        {points.map((p, i) => (
          <div key={i} className="flex gap-4 rounded-lg border border-border bg-card p-4 shadow-sm">
            <span className="text-3xl flex-shrink-0">{p.icon}</span>
            <div>
              <h3 className="font-semibold text-foreground">{p.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyChooseUs;
