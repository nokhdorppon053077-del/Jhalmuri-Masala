import { useEffect, useRef, useState } from "react";

interface HeroSectionProps {
  onOrderClick: () => void;
}

const HeroSection = ({ onOrderClick }: HeroSectionProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoFailed, setVideoFailed] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const attemptPlay = async () => {
      try {
        await video.play();
      } catch {
        video.muted = true;
        try {
          await video.play();
        } catch {
          setVideoFailed(true);
        }
      }
    };

    video.addEventListener("loadeddata", attemptPlay);
    if (video.readyState >= 2) attemptPlay();

    return () => video.removeEventListener("loadeddata", attemptPlay);
  }, []);

  return (
  <section className="relative w-full overflow-hidden bg-foreground">
    {/* Video in original aspect ratio */}
    {!videoFailed && (
      <video
        ref={videoRef}
        className="w-full"
        muted
        loop
        playsInline
        preload="auto"
      >
        <source src="/hero-video.mp4" type="video/mp4" />
      </video>
    )}
    {videoFailed && (
      <div className="w-full bg-gradient-to-br from-spice-warm/80 via-spice-orange/60 to-spice-red/70" style={{ aspectRatio: '16/9' }} />
    )}
    <div className="hero-overlay absolute inset-0" />

    <div className="absolute inset-0 z-10 flex flex-col items-center justify-center px-5 py-16 text-center">
      <h1 className="mb-2 text-2xl font-bold text-primary-foreground md:text-4xl leading-relaxed">
        Toha Organic Foods
      </h1>
      <p className="mb-6 max-w-md text-base text-primary-foreground/90 leading-relaxed md:text-lg">
        একটু মরিচ কুচি, একটু পেঁয়াজ কুচি, একটু মুড়ি আর আমাদের স্পেশাল ঝালমুড়ি মশলা = সেরা মুড়ি মাখা।
      </p>
      <button
        onClick={onOrderClick}
        className="animate-pulse-gentle rounded-full bg-primary px-8 py-3.5 text-lg font-bold text-primary-foreground shadow-lg transition-transform hover:scale-105 active:scale-95"
      >
        🟢 অর্ডার করতে চাই
      </button>
    </div>
  </section>
);
};

export default HeroSection;
