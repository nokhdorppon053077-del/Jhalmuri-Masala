const IngredientsSection = () => (
  <section className="bg-spice-cream px-5 py-12">
    <div className="mx-auto max-w-lg">
      <h2 className="mb-6 text-center text-xl font-bold text-foreground md:text-2xl">
        🌿 ব্যবহৃত উপাদান
      </h2>
      <div className="rounded-lg border border-border bg-card p-6 shadow-sm">
        <p className="text-foreground leading-loose">
          গরুর মাংসের কিমা / চুইঝাল + ঘানি ভাংগানো খাঁটি সরিষার তেল, কাশ্মীরী চিলি, আদা, রসুন,
          হলুদের গুঁড়া, জিরার গুঁড়া, লবঙ্গ, জয়ফল, জয়ত্রী, তেজপাতা সহ <strong>২৯ টি মশলা</strong>।
        </p>
      </div>
    </div>
  </section>
);

export default IngredientsSection;
