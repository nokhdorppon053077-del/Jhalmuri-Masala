import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import NoticeBar from "@/components/landing/NoticeBar";
import HeroSection from "@/components/landing/HeroSection";
import VariantSection from "@/components/landing/VariantSection";
import ReviewSlider from "@/components/landing/ReviewSlider";
import WhyChooseUs from "@/components/landing/WhyChooseUs";
import IngredientsSection from "@/components/landing/IngredientsSection";
import FAQSection from "@/components/landing/FAQSection";
import OrderSection from "@/components/landing/OrderSection";
import ExitIntentPopup from "@/components/landing/ExitIntentPopup";

const Index = () => {
  const navigate = useNavigate();
  const [selectedVariant, setSelectedVariant] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [discountApplied, setDiscountApplied] = useState(false);

  const scrollToOrder = useCallback(() => {
    document.getElementById("order-section")?.scrollIntoView({ behavior: "smooth" });
  }, []);

  const handleOrder = () => {
    if (selectedVariant && selectedSize) {
      navigate("/order", {
        state: { variant: selectedVariant, size: selectedSize, discountApplied },
      });
    }
  };

  const handleExitAccept = () => {
    setDiscountApplied(true);
    scrollToOrder();
  };

  return (
    <div className="min-h-screen bg-background">
      <NoticeBar />
      <HeroSection onOrderClick={scrollToOrder} />
      <VariantSection onOrderClick={scrollToOrder} />
      <ReviewSlider />
      <WhyChooseUs />
      <IngredientsSection />
      <FAQSection />
      <OrderSection
        selectedVariant={selectedVariant}
        setSelectedVariant={setSelectedVariant}
        selectedSize={selectedSize}
        setSelectedSize={setSelectedSize}
        discountApplied={discountApplied}
        onOrder={handleOrder}
      />
      <ExitIntentPopup onAccept={handleExitAccept} />

      {/* Footer */}
      <footer className="bg-foreground px-5 py-8 text-center">
        <p className="text-sm text-primary-foreground/70">© ২০২৫ Toha Organic Foods। সর্বস্বত্ব সংরক্ষিত।</p>
      </footer>
    </div>
  );
};

export default Index;
