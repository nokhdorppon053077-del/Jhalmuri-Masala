import { useEffect, useState, useRef } from "react";

interface ExitIntentPopupProps {
  onAccept: () => void;
}

const ExitIntentPopup = ({ onAccept }: ExitIntentPopupProps) => {
  const [show, setShow] = useState(false);
  const shownRef = useRef(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    if (sessionStorage.getItem("exit_popup_shown")) return;

    // Back button detection
    const handlePopState = () => {
      if (!shownRef.current) {
        window.history.pushState(null, "", window.location.href);
        triggerPopup();
      }
    };

    // beforeunload
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (!shownRef.current) triggerPopup();
    };

    // Fast scroll up detection
    const handleScroll = () => {
      const currentY = window.scrollY;
      const diff = lastScrollY.current - currentY;
      if (diff > 300 && currentY < 200 && !shownRef.current) {
        triggerPopup();
      }
      lastScrollY.current = currentY;
    };

    window.history.pushState(null, "", window.location.href);
    window.addEventListener("popstate", handlePopState);
    window.addEventListener("beforeunload", handleBeforeUnload);
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("popstate", handlePopState);
      window.removeEventListener("beforeunload", handleBeforeUnload);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const triggerPopup = () => {
    if (shownRef.current) return;
    shownRef.current = true;
    sessionStorage.setItem("exit_popup_shown", "1");
    setShow(true);
  };

  const handleAccept = () => {
    setShow(false);
    onAccept();
  };

  const handleDismiss = () => {
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center" onClick={handleDismiss}>
      <div className="animate-popup-overlay fixed inset-0 bg-foreground/50" />
      <div
        className="animate-popup-enter relative z-10 w-full max-w-md rounded-t-2xl sm:rounded-2xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Spice gradient background */}
        <div className="spice-gradient p-6 pb-8">
          <button
            onClick={handleDismiss}
            className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-foreground/10 text-foreground/60 hover:bg-foreground/20 transition-colors"
          >
            ✕
          </button>

          <div className="text-center">
            <p className="text-3xl mb-2">🌶️</p>
            <h3 className="text-2xl font-bold text-foreground">চলে যাচ্ছেন?</h3>
            <p className="mt-2 text-foreground/80">
              যাবার আগে নিয়ে যান আমাদের স্পেশাল ঝালমুড়ি মশলা।
            </p>
            <p className="mt-1 text-sm text-foreground/70">
              আজ অর্ডার করলে পাচ্ছেন বিশেষ মূল্যছাড়!
            </p>

            {/* Discount badge */}
            <div className="mt-4 inline-block rounded-full bg-spice-red/15 px-5 py-2">
              <span className="text-lg font-bold text-spice-red">৫০ টাকা ছাড়</span>
            </div>
          </div>
        </div>

        <div className="bg-card p-5 space-y-3">
          <button
            onClick={handleAccept}
            className="w-full rounded-full bg-primary py-3.5 text-lg font-bold text-primary-foreground shadow-lg transition-transform hover:scale-[1.02] active:scale-95"
          >
            🟢 এখনি অর্ডার করে ফেলি
          </button>
          <button
            onClick={handleDismiss}
            className="w-full rounded-full border border-border py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted/50"
          >
            পরে নিব
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExitIntentPopup;
