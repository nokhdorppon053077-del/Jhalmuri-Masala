import useEmblaCarousel from "embla-carousel-react";
import { useEffect, useCallback, useState } from "react";

const reviews = [
  { name: "রাহেলা খাতুন", text: "অসাধারণ স্বাদ! পরিবারের সবাই পছন্দ করেছে। 🌶️", rating: 5 },
  { name: "মো: আরিফ", text: "রাস্তার ঝালমুড়ির সেই স্বাদ ঘরে পেয়ে গেলাম!", rating: 5 },
  { name: "ফাতেমা বেগম", text: "ক্যামিকেলমুক্ত হওয়ায় নিশ্চিন্তে বাচ্চাদেরও দিতে পারি।", rating: 5 },
  { name: "সাকিব হাসান", text: "গরুর কিমার টা একদম ফাটাফাটি! আবার অর্ডার দিবো।", rating: 5 },
  { name: "নুসরাত জাহান", text: "চুইঝালের মশলা দিয়ে ভাত খেলাম, অসাধারণ!", rating: 5 },
  { name: "মাহমুদুল হক", text: "ডেলিভারি খুব দ্রুত পেয়েছি। মশলার মান চমৎকার।", rating: 4 },
  { name: "সুমাইয়া আক্তার", text: "৬ মাস সংরক্ষণ করা যায়, তাই বড় প্যাক নিয়েছি।", rating: 5 },
  { name: "তানভীর আহমেদ", text: "বন্ধুদের গিফট দিলাম, সবাই মুগ্ধ!", rating: 5 },
  { name: "শারমিন সুলতানা", text: "মশলার ঘ্রাণে জিভে পানি চলে আসে, সত্যি কথা!", rating: 5 },
  { name: "রবিউল ইসলাম", text: "চিতই পিঠা দিয়ে খেলাম, নতুন স্বাদ পেলাম!", rating: 5 },
  { name: "আয়েশা সিদ্দিকা", text: "প্যাকেজিং সুন্দর, মশলা ফ্রেশ। ধন্যবাদ Toha!", rating: 5 },
  { name: "কামরুল হাসান", text: "সেরা ঝালমুড়ি মশলা। অন্য কিছু খাওয়ার ইচ্ছা নেই!", rating: 5 },
];

const Stars = ({ count }: { count: number }) => (
  <span className="text-spice-gold">{"★".repeat(count)}{"☆".repeat(5 - count)}</span>
);

const ReviewSlider = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: true,
    align: "start",
    dragFree: true,
  });

  const [isHovered, setIsHovered] = useState(false);

  const autoScroll = useCallback(() => {
    if (!emblaApi || isHovered) return;
    emblaApi.scrollNext();
  }, [emblaApi, isHovered]);

  useEffect(() => {
    const interval = setInterval(autoScroll, 3000);
    return () => clearInterval(interval);
  }, [autoScroll]);

  return (
    <section className="bg-spice-cream py-12 overflow-hidden">
      <div className="px-5 mb-6 text-center">
        <h2 className="text-xl font-bold text-foreground md:text-2xl">⭐ কাস্টমার রিভিউ</h2>
      </div>
      <div
        className="overflow-hidden px-5"
        ref={emblaRef}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="flex gap-4">
          {reviews.map((r, i) => (
            <div
              key={i}
              className="flex-shrink-0 w-64 flex flex-col rounded-lg border border-border bg-card p-4 shadow-sm"
            >
              <Stars count={r.rating} />
              <p className="mt-2 text-sm text-foreground leading-relaxed">{r.text}</p>
              <p className="mt-3 text-xs font-semibold text-muted-foreground">— {r.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ReviewSlider;
