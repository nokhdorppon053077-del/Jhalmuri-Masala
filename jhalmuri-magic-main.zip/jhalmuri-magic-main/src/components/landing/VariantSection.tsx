import productKima from "@/assets/product-kima.png";
import productChuijhal from "@/assets/product-chuijhal.png";

interface VariantSectionProps {
  onOrderClick: () => void;
}

const VariantSection = ({ onOrderClick }: VariantSectionProps) => (
  <section className="bg-background px-5 py-12">
    <div className="mx-auto max-w-lg text-center">
      <h2 className="mb-2 text-xl font-bold text-foreground md:text-2xl">
        🌶️ আমাদের ঝালমুড়ি মশলা
      </h2>
      <p className="mb-8 text-muted-foreground leading-relaxed">
        আমাদের ঝালমুড়ি মশলা ২টি ভ্যারিয়েন্টে পাওয়া যাচ্ছে—
      </p>

      <div className="space-y-6">
        <div className="overflow-hidden rounded-lg border border-border bg-card shadow-sm transition-shadow hover:shadow-md">
          <img src={productKima} alt="গরুর কিমার ঝালমুড়ি মশলা" className="w-full object-cover" loading="lazy" />
          <div className="p-4">
            <h3 className="text-lg font-semibold text-foreground">১) গরুর কিমার ঝালমুড়ি মশলা</h3>
          </div>
        </div>

        <div className="overflow-hidden rounded-lg border border-border bg-card shadow-sm transition-shadow hover:shadow-md">
          <img src={productChuijhal} alt="চুইঝালের স্পেশাল ঝালমুড়ি মশলা" className="w-full object-cover" loading="lazy" />
          <div className="p-4">
            <h3 className="text-lg font-semibold text-foreground">২) চুইঝালের স্পেশাল ঝালমুড়ি মশলা</h3>
          </div>
        </div>
      </div>

      <button
        onClick={onOrderClick}
        className="mt-8 rounded-full bg-primary px-8 py-3.5 text-lg font-bold text-primary-foreground shadow-lg transition-transform hover:scale-105 active:scale-95"
      >
        🟢 অর্ডার করতে চাই
      </button>
    </div>
  </section>
);

export default VariantSection;
