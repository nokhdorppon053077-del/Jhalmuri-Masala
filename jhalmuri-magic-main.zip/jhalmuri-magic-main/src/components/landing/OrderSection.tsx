interface OrderSectionProps {
  selectedVariant: string | null;
  setSelectedVariant: (v: string) => void;
  selectedSize: string | null;
  setSelectedSize: (s: string) => void;
  discountApplied: boolean;
  onOrder: () => void;
}

const variants = [
  { id: "kima", label: "গরুর কিমার ঝালমুড়ি মশলা" },
  { id: "chuijhal", label: "চুইঝালের স্পেশাল ঝালমুড়ি মশলা" },
];

const sizes = [
  { id: "500ml", label: "৫০০ ml", price: 650 },
  { id: "1l", label: "১ লিটার", price: 1090 },
];

const OrderSection = ({
  selectedVariant,
  setSelectedVariant,
  selectedSize,
  setSelectedSize,
  discountApplied,
  onOrder,
}: OrderSectionProps) => {
  const isReady = selectedVariant && selectedSize;

  const getPrice = (basePrice: number) => (discountApplied ? basePrice - 50 : basePrice);

  return (
    <section id="order-section" className="bg-spice-cream px-5 py-12">
      <div className="mx-auto max-w-lg">
        <h2 className="mb-8 text-center text-xl font-bold text-foreground md:text-2xl">
          🛒 অর্ডার করুন
        </h2>

        {/* Discount badge */}
        {discountApplied && (
          <div className="mb-6 rounded-lg bg-primary/10 border border-primary/30 p-3 text-center text-sm font-semibold text-primary">
            🎉 ৫০ টাকা ডিসকাউন্ট প্রযোজ্য!
          </div>
        )}

        {/* Step 1: Variant */}
        <div className="mb-6">
          <h3 className="mb-3 font-semibold text-foreground">১. ভ্যারিয়েন্ট বাছাই করুন</h3>
          <div className="space-y-3">
            {variants.map((v) => (
              <label
                key={v.id}
                className={`flex cursor-pointer items-center gap-3 rounded-lg border p-4 transition-all ${
                  selectedVariant === v.id
                    ? "border-primary bg-primary/5 selection-ring"
                    : "border-border bg-card hover:border-primary/40"
                }`}
              >
                <span
                  className={`flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                    selectedVariant === v.id ? "border-primary bg-primary" : "border-muted-foreground"
                  }`}
                >
                  {selectedVariant === v.id && (
                    <span className="h-2 w-2 rounded-full bg-primary-foreground" />
                  )}
                </span>
                <input
                  type="radio"
                  name="variant"
                  value={v.id}
                  checked={selectedVariant === v.id}
                  onChange={() => setSelectedVariant(v.id)}
                  className="sr-only"
                />
                <span className="text-foreground font-medium">{v.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Step 2: Size */}
        <div className="mb-8">
          <h3 className="mb-3 font-semibold text-foreground">২. সাইজ বাছাই করুন</h3>
          <div className="grid grid-cols-2 gap-3">
            {sizes.map((s) => (
              <button
                key={s.id}
                onClick={() => setSelectedSize(s.id)}
                className={`relative overflow-hidden rounded-lg border p-4 text-center transition-all ${
                  selectedSize === s.id
                    ? "border-primary bg-primary/5 selection-ring"
                    : "border-border bg-card hover:border-primary/40"
                }`}
              >
                <span className="absolute right-0 top-0 rounded-bl-lg bg-spice-orange px-2 py-0.5 text-[10px] font-bold text-accent-foreground">
                  ফ্রি ডেলিভারি
                </span>
                <p className="mt-2 text-lg font-bold text-foreground">{s.label}</p>
                {discountApplied ? (
                  <div className="mt-1">
                    <span className="text-xs text-muted-foreground line-through">৳{s.price}</span>
                    <span className="ml-2 text-lg font-bold text-primary">৳{getPrice(s.price)}</span>
                  </div>
                ) : (
                  <p className="mt-1 text-lg font-bold text-primary">৳{s.price}</p>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Step 3: Order Button */}
        <button
          onClick={onOrder}
          disabled={!isReady}
          className={`w-full rounded-full py-4 text-lg font-bold shadow-lg transition-all ${
            isReady
              ? "bg-primary text-primary-foreground hover:scale-[1.02] active:scale-95"
              : "cursor-not-allowed bg-muted text-muted-foreground"
          }`}
        >
          🟢 অর্ডার করুন (COD)
        </button>
        <p className="mt-2 text-center text-xs text-muted-foreground">ক্যাশ অন ডেলিভারি</p>
      </div>
    </section>
  );
};

export default OrderSection;
