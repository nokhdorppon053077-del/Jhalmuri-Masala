const NoticeBar = () => (
  <div className="sticky top-0 z-50 bg-notice-bg py-2 text-center text-sm font-semibold text-notice-fg tracking-wide">
    🚚 সারাদেশে ডেলিভারি চার্জ ফ্রি
  </div>
);

export default NoticeBar;
