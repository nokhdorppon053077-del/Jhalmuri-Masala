import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { z } from "zod";

const variantLabels: Record<string, string> = {
  kima: "গরুর কিমার ঝালমুড়ি মশলা",
  chuijhal: "চুইঝালের স্পেশাল ঝালমুড়ি মশলা",
};

const sizeData: Record<string, { label: string; price: number }> = {
  "500ml": { label: "৫০০ ml", price: 650 },
  "1l": { label: "১ লিটার", price: 1090 },
};

const orderSchema = z.object({
  name: z.string().trim().min(1, "নাম দিন").max(100),
  phone: z.string().trim().min(11, "সঠিক ফোন নম্বর দিন").max(15).regex(/^0\d{10,}$/, "সঠিক ফোন নম্বর দিন (01...)"),
  address: z.string().trim().min(5, "সম্পূর্ণ ঠিকানা দিন").max(500),
});

const OrderPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { variant, size, discountApplied } = (location.state as {
    variant: string;
    size: string;
    discountApplied: boolean;
  }) || {};

  const [form, setForm] = useState({ name: "", phone: "", address: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  if (!variant || !size) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5">
        <p className="text-lg text-foreground mb-4">কোনো প্রোডাক্ট সিলেক্ট করা হয়নি।</p>
        <button onClick={() => navigate("/")} className="rounded-full bg-primary px-6 py-3 text-primary-foreground font-bold">
          🏠 হোম পেজে যান
        </button>
      </div>
    );
  }

  const s = sizeData[size];
  const discount = discountApplied ? 50 : 0;
  const total = s.price - discount;

  const handleSubmit = () => {
    const result = orderSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((e) => {
        if (e.path[0]) fieldErrors[e.path[0] as string] = e.message;
      });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    // TODO: WooCommerce API integration here
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5 text-center">
        <div className="text-5xl mb-4">✅</div>
        <h2 className="text-2xl font-bold text-foreground mb-2">অর্ডার সফল হয়েছে!</h2>
        <p className="text-muted-foreground mb-2">ধন্যবাদ, {form.name}!</p>
        <p className="text-sm text-muted-foreground mb-6">আমাদের প্রতিনিধি শীঘ্রই আপনার সাথে যোগাযোগ করবেন।</p>
        <button onClick={() => navigate("/")} className="rounded-full bg-primary px-6 py-3 text-primary-foreground font-bold">
          🏠 হোম পেজে যান
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary px-5 py-4">
        <div className="mx-auto max-w-lg flex items-center gap-3">
          <button onClick={() => navigate("/")} className="text-primary-foreground text-xl">←</button>
          <h1 className="text-lg font-bold text-primary-foreground">অর্ডার ফর্ম</h1>
        </div>
      </div>

      <div className="mx-auto max-w-lg px-5 py-8 space-y-6">
        {/* Order Summary */}
        <div className="rounded-lg border border-border bg-card p-4 space-y-3">
          <h3 className="font-bold text-foreground">🧾 অর্ডার সামারি</h3>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">ভ্যারিয়েন্ট</span>
            <span className="font-medium text-foreground">{variantLabels[variant]}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">সাইজ</span>
            <span className="font-medium text-foreground">{s.label}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">মূল্য</span>
            <span className="font-medium text-foreground">৳{s.price}</span>
          </div>
          {discountApplied && (
            <div className="flex justify-between text-sm">
              <span className="text-primary">ডিসকাউন্ট</span>
              <span className="font-medium text-primary">-৳{discount}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">ডেলিভারি</span>
            <span className="font-medium text-primary">ফ্রি</span>
          </div>
          <div className="border-t border-border pt-3 flex justify-between">
            <span className="font-bold text-foreground">মোট</span>
            <span className="text-xl font-bold text-primary">৳{total}</span>
          </div>
        </div>

        {/* Customer Form */}
        <div className="space-y-4">
          <h3 className="font-bold text-foreground">📋 আপনার তথ্য দিন</h3>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1">নাম *</label>
            <input
              type="text"
              placeholder="আপনার পূর্ণ নাম"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              maxLength={100}
            />
            {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1">ফোন নম্বর *</label>
            <input
              type="tel"
              placeholder="01XXXXXXXXX"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              maxLength={15}
            />
            {errors.phone && <p className="text-sm text-destructive mt-1">{errors.phone}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1">ডেলিভারি ঠিকানা *</label>
            <textarea
              placeholder="সম্পূর্ণ ঠিকানা লিখুন (বাসা, রাস্তা, এলাকা, জেলা)"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              rows={3}
              className="w-full rounded-lg border border-input bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              maxLength={500}
            />
            {errors.address && <p className="text-sm text-destructive mt-1">{errors.address}</p>}
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          className="w-full rounded-full bg-primary py-4 text-lg font-bold text-primary-foreground shadow-lg transition-transform hover:scale-[1.02] active:scale-95"
        >
          ✅ অর্ডার কনফার্ম করুন (COD)
        </button>
        <p className="text-center text-xs text-muted-foreground">ক্যাশ অন ডেলিভারি • ফ্রি ডেলিভারি</p>
      </div>
    </div>
  );
};

export default OrderPage;
