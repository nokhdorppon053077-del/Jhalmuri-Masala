import { useState } from "react";

const faqs = [
  {
    q: "কতোদিন সংরক্ষণ করা যায়?",
    a: "ফ্রিজে ৬ মাসের বেশি এবং ফ্রিজের বাইরে ১ মাস এর বেশি সংরক্ষণ করে খাওয়া যায়।",
  },
  {
    q: "ডেলিভারি চার্জ কি ফ্রি?",
    a: "জি রমজান উপলক্ষ্যে সারাদেশে ডেলিভারি চার্জ ফ্রি।",
  },
  {
    q: "৫০০ ml মশলা দিয়ে কতোটা মুড়ি মাখানো যায়?",
    a: "এটা আপনার স্বাদের উপর নির্ভর করবে, তবে সাধারণভাবে ৫০০ ml মশলা দিয়ে ৫/৬ কেজি মুড়ি অনায়েসেই মাখানো যায়।",
  },
  {
    q: "কোনটা বেশি মজাদার?",
    a: "আলহামদুলিল্লাহ দুইটাই অনেক মজাদার। গরুর কিমার টাতে গরুর মাংসের স্বাদ এবং ঘ্রাণ পাবেন। চুইঝালের টাতে প্রাকৃতিক একটা ঝাল ঝাল ভাব পাবেন এবং নতুন একটা স্বাদ পাবেন।",
  },
];

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="bg-background px-5 py-12">
      <div className="mx-auto max-w-lg">
        <h2 className="mb-8 text-center text-xl font-bold text-foreground md:text-2xl">
          ❓ সাধারণ জিজ্ঞাসা
        </h2>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="overflow-hidden rounded-lg border border-border bg-card shadow-sm">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="flex w-full items-center justify-between p-4 text-left font-semibold text-foreground transition-colors hover:bg-muted/50"
              >
                <span>{faq.q}</span>
                <span
                  className="ml-3 flex-shrink-0 text-xl text-muted-foreground transition-transform duration-300"
                  style={{ transform: openIndex === i ? "rotate(45deg)" : "rotate(0)" }}
                >
                  +
                </span>
              </button>
              <div
                className={`faq-answer ${openIndex === i ? "open" : ""}`}
                style={{ maxHeight: openIndex === i ? "500px" : "0" }}
              >
                <p className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{faq.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
